from funds.models import Fund, Status, Favo, Issuer, Fund_type, Settlement_day, Currency
# from funds.owner import OwnerListView, OwnerDetailView, OwnerCreateView, OwnerUpdateView, OwnerDeleteView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.http import HttpResponse
from django.views import View
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
# from funds.forms import CreateForm

# from funds.forms import CommentForm
from django.urls import reverse

from django.contrib.humanize.templatetags.humanize import naturaltime
from django.db.models import Q

class IntroView(LoginRequiredMixin, View):
    template_name = "funds/fund_intro.html"

    def get(self, request) :
        return render(request, self.template_name)


class FundListView(LoginRequiredMixin, View):
    model = Fund
    template_name = "funds/fund_list.html"

    def get(self, request) :

        #change 20211201
        strval = request.GET.get("search", False)
        title_check = request.GET.get("title_check")
        note_check = request.GET.get("note_check", False)
        fund_code_check = request.GET.get("fund_code_check", False)
        issuer_check = request.GET.get("issuer_check", False)
        fund_type_check = request.GET.get("fund_type_check", False)
        settlement_day_check =  request.GET.get("settlement_day_check", False)
        currency_check =  request.GET.get("currency_check", False)
        status_check = request.GET.get("status_check", False)

        if strval :
            # Simple title-only search
            # objects = Fund.objects.filter(title__contains=strval).select_related().order_by('-updated_at')[:10]

            # Multi-field search
            # __icontains for case-insensitive search
            query = Q()
            if title_check == "y":
                query.add(Q(title__icontains=strval), Q.OR)
                # query = Q(title__icontains=strval)
            if note_check == "y":
                query.add(Q(note__icontains=strval), Q.OR)
            if fund_code_check == "y":
                query.add(Q(fund_code__icontains=strval), Q.OR)
            if issuer_check != "all":
                query.add(Q(issuer__issuer__icontains=issuer_check), Q.AND)
            if fund_type_check != "all":
                query.add(Q(fund_type__fund_type__icontains=fund_type_check), Q.AND)
            if settlement_day_check != "all":
                query.add(Q(settlement_day__settlement_day__icontains=settlement_day_check), Q.AND)
            if currency_check != "all":
                query.add(Q(currency__currency__icontains=currency_check), Q.AND)
            if status_check != "all":
                query.add(Q(status__status__icontains=status_check), Q.AND)

            # fund_list = Fund.objects.filter(query).select_related().order_by('-updated_at')[:10] #old version order by time
            fund_list = Fund.objects.filter(query).select_related().order_by('fund_code')
        else :
            # fund_list = Fund.objects.all().order_by('-updated_at')[:10]
            fund_list = Fund.objects.all().order_by('fund_code')

        # Augment the fund_list
        for obj in fund_list:
            obj.natural_updated = naturaltime(obj.updated_at)
        #change end

        # fund_list = Fund.objects.all()
        favorites = list()
        if request.user.is_authenticated:
            # rows = [{'id': 2}, {'id': 4} ... ]  (A list of rows)
            rows = request.user.favorite_funds.values('id')
            # favorites = [2, 4, ...] using list comprehension
            favorites = [ row['id'] for row in rows ]

        sc = Status.objects.all().count()
        ic = Issuer.objects.all().count()
        ftc = Fund_type.objects.all().count()
        sdc = Settlement_day.objects.all().count()
        cc = Currency.objects.all().count()

        ia = Issuer.objects.all()
        fta = Fund_type.objects.all()
        sda = Settlement_day.objects.all()
        ca = Currency.objects.all()
        sa = Status.objects.all()

        ctx = {'fund_list' : fund_list, 'favorites': favorites, 'search': strval,
        'status_count': sc,
        'issuer_count': ic,
        'fund_type_count': ftc,
        'settlement_day_count': sdc,
        'currency_count': cc,
        'title_check' : title_check,
        'issuer_all':ia,
        'fund_type_all':fta,
        'settlement_day_all':sda,
        'currency_all':ca,
        'status_all':sa
        }

        return render(request, self.template_name, ctx)

class FundDetailView(LoginRequiredMixin, View):
    model = Fund
    template_name = "funds/fund_detail.html"
    def get(self, request, pk) :
        x = Fund.objects.get(id=pk)

        context = { 'fund' : x }
        return render(request, self.template_name, context)


class FundCreate(LoginRequiredMixin, CreateView):
    model = Fund
    fields = ['title','fund_code','issuer','fund_type','settlement_day','currency','note','status'] # originally ['title', 'text','price']
    success_url =reverse_lazy('funds:all')

class FundUpdate(LoginRequiredMixin, UpdateView):
    model = Fund
    fields = ['title','fund_code','issuer','fund_type','settlement_day','currency','note','status']
    success_url = reverse_lazy('funds:all')


class FundDelete(LoginRequiredMixin, DeleteView):
    model = Fund
    fields = '__all__'
    success_url = reverse_lazy('funds:all')

# def stream_file(request, pk):
#     fund = get_object_or_404(Fund, id=pk)
#     response = HttpResponse()
#     response['Content-Type'] = fund.content_type
#     response['Content-Length'] = len(fund.picture)
#     response.write(fund.picture)
#     return response

# Status
class StatusView(LoginRequiredMixin, View):
    model = Status
    def get(self, request):
        status = Status.objects.all()

        ctx = {'status_list':status}
        return render(request, 'funds/status_list.html',ctx)

class StatusCreate(LoginRequiredMixin, CreateView):
    model = Status
    fields = '__all__'
    success_url = reverse_lazy('funds:status_list')

class StatusUpdate(LoginRequiredMixin, UpdateView):
    model = Status
    fields = '__all__'
    success_url = reverse_lazy('funds:status_list')

class StatusDelete(LoginRequiredMixin, DeleteView):
    model = Status
    fields = '__all__'
    success_url = reverse_lazy('funds:status_list')


# Issuer
class IssuerView(LoginRequiredMixin, View):
    model = Issuer
    def get(self, request):
        issuer = Issuer.objects.all()

        ctx = {'issuer_list':issuer}
        return render(request, 'funds/issuer_list.html',ctx)

class IssuerCreate(LoginRequiredMixin, CreateView):
    model = Issuer
    fields = '__all__'
    success_url = reverse_lazy('funds:issuer_list')

class IssuerUpdate(LoginRequiredMixin, UpdateView):
    model = Issuer
    fields = '__all__'
    success_url = reverse_lazy('funds:issuer_list')

class IssuerDelete(LoginRequiredMixin, DeleteView):
    model = Issuer
    fields = '__all__'
    success_url = reverse_lazy('funds:issuer_list')


# Fund_type
class Fund_typeView(LoginRequiredMixin, View):
    model = Fund_type
    def get(self, request):
        fund_type = Fund_type.objects.all()

        ctx = {'fund_type_list':fund_type}
        return render(request, 'funds/fund_type_list.html',ctx)

class Fund_typeCreate(LoginRequiredMixin, CreateView):
    model = Fund_type
    fields = '__all__'
    success_url = reverse_lazy('funds:fund_type_list')

class Fund_typeUpdate(LoginRequiredMixin, UpdateView):
    model = Fund_type
    fields = '__all__'
    success_url = reverse_lazy('funds:fund_type_list')

class Fund_typeDelete(LoginRequiredMixin, DeleteView):
    model = Fund_type
    fields = '__all__'
    success_url = reverse_lazy('funds:fund_type_list')

# Settlement_day
class Settlement_dayView(LoginRequiredMixin, View):
    model = Settlement_day
    def get(self, request):
        settlement_day = Settlement_day.objects.all()

        ctx = {'settlement_day_list':settlement_day}
        return render(request, 'funds/settlement_day_list.html',ctx)

class Settlement_dayCreate(LoginRequiredMixin, CreateView):
    model = Settlement_day
    fields = '__all__'
    success_url = reverse_lazy('funds:settlement_day_list')

class Settlement_dayUpdate(LoginRequiredMixin, UpdateView):
    model = Settlement_day
    fields = '__all__'
    success_url = reverse_lazy('funds:settlement_day_list')

class Settlement_dayDelete(LoginRequiredMixin, DeleteView):
    model = Settlement_day
    fields = '__all__'
    success_url = reverse_lazy('funds:settlement_day_list')

# Currency
class CurrencyView(LoginRequiredMixin, View):
    model = Currency
    def get(self, request):
        currency = Currency.objects.all()

        ctx = {'currency_list':currency}
        return render(request, 'funds/currency_list.html',ctx)

class CurrencyCreate(LoginRequiredMixin, CreateView):
    model = Currency
    fields = '__all__'
    success_url = reverse_lazy('funds:currency_list')

class CurrencyUpdate(LoginRequiredMixin, UpdateView):
    model = Currency
    fields = '__all__'
    success_url = reverse_lazy('funds:currency_list')

class CurrencyDelete(LoginRequiredMixin, DeleteView):
    model = Currency
    fields = '__all__'
    success_url = reverse_lazy('funds:currency_list')




# csrf exemption in class based views
# https://stackoverflow.com/questions/16458166/how-to-disable-djangos-csrf-validation
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.db.utils import IntegrityError

@method_decorator(csrf_exempt, name='dispatch')
class FundAddFavoriteView(LoginRequiredMixin, View):
    def post(self, request, pk) :
        print("Add PK",pk)
        t = get_object_or_404(Fund, id=pk)
        favo = Favo(user=request.user, fund=t)
        try:
            favo.save()  # In case of duplicate key
        except IntegrityError as e:
            pass
        return HttpResponse()

@method_decorator(csrf_exempt, name='dispatch')
class FundDeleteFavoriteView(LoginRequiredMixin, View):
    def post(self, request, pk) :
        print("Delete PK",pk)
        t = get_object_or_404(Fund, id=pk)
        try:
            favo = Favo.objects.get(user=request.user, fund=t).delete()
        except Favo.DoesNotExist as e:
            pass

        return HttpResponse()