from django.urls import path
from . import views

app_name='funds'
urlpatterns = [

    path('', views.IntroView.as_view(), name='intro'),

    path('fund/', views.FundListView.as_view(), name='all'),
    path('fund/<int:pk>', views.FundDetailView.as_view(), name='fund_detail'),
    path('fund/create', views.FundCreate.as_view(), name='fund_create'),
    path('fund/<int:pk>/update', views.FundUpdate.as_view(), name='fund_update'),
    path('fund/<int:pk>/delete', views.FundDelete.as_view(), name='fund_delete'),
    # path('fund_picture/<int:pk>', views.stream_file, name='fund_picture'),
    # path('fund/<int:pk>/comment', views.CommentCreateView.as_view(), name='fund_comment_create'),
    # path('comment/<int:pk>/delete', views.CommentDeleteView.as_view(success_url=reverse_lazy('funds')), name='fund_comment_delete'),

    # status
    path('st_lookup/', views.StatusView.as_view(), name='status_list'),
    path('st_lookup/create/', views.StatusCreate.as_view(), name='status_create'),
    path('st_lookup/<int:pk>/update/', views.StatusUpdate.as_view(), name='status_update'),
    path('st_lookup/<int:pk>/delete/', views.StatusDelete.as_view(), name='status_delete'),

    # issuer
    path('is_lookup/', views.IssuerView.as_view(), name='issuer_list'),
    path('is_lookup/create/', views.IssuerCreate.as_view(), name='issuer_create'),
    path('is_lookup/<int:pk>/update/', views.IssuerUpdate.as_view(), name='issuer_update'),
    path('is_lookup/<int:pk>/delete/', views.IssuerDelete.as_view(), name='issuer_delete'),

    # fund_type
    path('ft_lookup/', views.Fund_typeView.as_view(), name='fund_type_list'),
    path('ft_lookup/create/', views.Fund_typeCreate.as_view(), name='fund_type_create'),
    path('ft_lookup/<int:pk>/update/', views.Fund_typeUpdate.as_view(), name='fund_type_update'),
    path('ft_lookup/<int:pk>/delete/', views.Fund_typeDelete.as_view(), name='fund_type_delete'),

    # settlement_day
    path('sd_lookup/', views.Settlement_dayView.as_view(), name='settlement_day_list'),
    path('sd_lookup/create/', views.Settlement_dayCreate.as_view(), name='settlement_day_create'),
    path('sd_lookup/<int:pk>/update/', views.Settlement_dayUpdate.as_view(), name='settlement_day_update'),
    path('sd_lookup/<int:pk>/delete/', views.Settlement_dayDelete.as_view(), name='settlement_day_delete'),

    # currency
    path('c_lookup/', views.CurrencyView.as_view(), name='currency_list'),
    path('c_lookup/create/', views.CurrencyCreate.as_view(), name='currency_create'),
    path('c_lookup/<int:pk>/update/', views.CurrencyUpdate.as_view(), name='currency_update'),
    path('c_lookup/<int:pk>/delete/', views.CurrencyDelete.as_view(), name='currency_delete'),



    path('fund/<int:pk>/favorite', views.FundAddFavoriteView.as_view(), name='fund_favorite'),
    path('fund/<int:pk>/unfavorite', views.FundDeleteFavoriteView.as_view(), name='fund_unfavorite')
]

# We use reverse_lazy in urls.py to delay looking up the view until all the paths are defined
