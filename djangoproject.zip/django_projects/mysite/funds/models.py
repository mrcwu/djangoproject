from django.db import models
from django.core.validators import MinLengthValidator
from django.conf import settings

class Status(models.Model):
    status = models.CharField(max_length = 200, validators=[MinLengthValidator(2, "Status must be greater than 1 character")])

    def __str__(self):
        return self.status

class Issuer(models.Model) :
    issuer = models.CharField(max_length=255)
    def __str__(self):
        return self.issuer

class Fund_type(models.Model) :

    fund_type = models.CharField(max_length=255)
    def __str__(self):
        return self.fund_type

class Settlement_day(models.Model) :

    settlement_day = models.CharField(max_length=255)
    def __str__(self):
        return self.settlement_day

class Currency(models.Model) :

    currency = models.CharField(max_length=255)
    def __str__(self):
        return self.currency


class Fund(models.Model) :

    title = models.CharField(
            max_length=255,
            validators=[MinLengthValidator(2, "Title must be greater than 2 characters")]
    )
    fund_code = models.CharField(max_length=255, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    issuer = models.ForeignKey('Issuer', on_delete=models.CASCADE)
    fund_type = models.ForeignKey('Fund_type', on_delete=models.CASCADE)
    settlement_day = models.ForeignKey('Settlement_day', on_delete=models.CASCADE)
    currency = models.ForeignKey('Currency', on_delete=models.CASCADE)
    note = models.TextField()
    status = models.ForeignKey('Status', on_delete=models.CASCADE, null=False)
    # Favorites
    favorites = models.ManyToManyField(settings.AUTH_USER_MODEL,
        through='Favo', related_name='favorite_funds')


    def __str__(self):
        return self.title


class Favo(models.Model) :
    fund = models.ForeignKey(Fund, on_delete=models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)


    class Meta:
        unique_together = ('fund', 'user')

    def __str__(self) :
        return '%s likes %s'%(self.user.username, self.fund.title[:10])



