from django.contrib import admin

# Register your models here.
from pets.models import Pet, Type

admin.site.register(Pet)
admin.site.register(Type)