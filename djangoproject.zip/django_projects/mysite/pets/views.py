from django.shortcuts import render
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
# Create your views here.

from pets.models import Pet, Type



class MainView(LoginRequiredMixin, View):
    def get(self, request):
        tc = Type.objects.all().count()
        pl = Pet.objects.all()

        ctx = {'type_count':tc, 'pet_list':pl}
        return render(request, 'pets/pet_list.html', ctx)


class TypeView(LoginRequiredMixin, View):
    def get(self, request):
        tl = Type.objects.all()

        ctx = {'type_list':tl}
        return render(request, 'pets/type_list.html', ctx)



class PetCreate(LoginRequiredMixin, CreateView):
    model = Pet
    fields = '__all__'
    success_url = reverse_lazy('pets:all')
class PetUpdate(LoginRequiredMixin, UpdateView):
    model = Pet
    fields = '__all__'
    success_url = reverse_lazy('pets:all')
class PetDelete(LoginRequiredMixin, DeleteView):
    model = Pet
    fields = '__all__'
    success_url = reverse_lazy('pets:all')


class TypeCreate(LoginRequiredMixin, CreateView):
    model = Type
    fields = '__all__'
    success_url = reverse_lazy('pets:all')
class TypeUpdate(LoginRequiredMixin, UpdateView):
    model = Type
    fields = '__all__'
    success_url = reverse_lazy('pets:all')
class TypeDelete(LoginRequiredMixin, DeleteView):
    model = Type
    fields = '__all__'
    success_url = reverse_lazy('pets:all')
