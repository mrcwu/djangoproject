from django.shortcuts import render
from django.views import generic
from django.http import HttpResponse


# Create your views here.

# class myview(generic.DetailView):
#     model = Question
#     template_name = 'polls/detail.html'

def cookie_n_session(request):

    num_visits = request.session.get('num_visits', 0) + 1
    request.session['num_visits'] = num_visits
    if num_visits > 4 : del(request.session['num_visits'])

    print(request.COOKIES)
    resp = HttpResponse('43a4d135' + " view count=" + str(num_visits))
    # resp.set_cookie('testing', 42) # No expired date = until browser close
    resp.set_cookie('dj4e_cookie', '43a4d135', max_age=1000)

    return resp #HttpResponse('view count='+str(num_visits))
