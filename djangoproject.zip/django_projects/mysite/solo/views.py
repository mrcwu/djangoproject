# from django.views.generic.edit import CreateView, UpdateView, DeleteView
# from django.http import HttpResponse
# from django.views import View
# from django.shortcuts import render, redirect, get_object_or_404
# from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin

# from django.urls import reverse
# from django.contrib.humanize.templatetags.humanize import naturaltime
# from django.db.models import Q


from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
import html
from django.views.decorators.csrf import csrf_exempt
from django.views import View


def checkguess(field1, field2) :
    msg = False

    msg = "Your result is " + str(field1[::-1]).upper() + " " + str(field2[::-1]).upper()

    return msg

# def guess(request):
#     guess = request.POST.get('guess')
#     msg = checkguess(guess)
#     return render(request, 'solo/guess.html', {'message' : msg })

class ClassyView(LoginRequiredMixin, View) :
    def get(self, request):
        return render(request, 'solo/guess.html')

    def post(self, request):
        field1 = request.POST.get('field1')
        field2 = request.POST.get('field2')
        msg = checkguess(field1, field2)
        return render(request, 'solo/guess.html', {'message' : msg })









    # def get(self, request) :

    #     #change 20211201
    #     strval = request.GET.get("search", False)
    #     title_check = request.GET.get("title_check")
    #     note_check = request.GET.get("note_check", False)
    #     fund_code_check = request.GET.get("fund_code_check", False)
    #     issuer_check = request.GET.get("issuer_check", False)
    #     fund_type_check = request.GET.get("fund_type_check", False)
    #     settlement_day_check =  request.GET.get("settlement_day_check", False)
    #     currency_check =  request.GET.get("currency_check", False)
    #     status_check = request.GET.get("status_check", False)

    #     if strval :
    #         # Simple title-only search
    #         # objects = Fund.objects.filter(title__contains=strval).select_related().order_by('-updated_at')[:10]

    #         # Multi-field search
    #         # __icontains for case-insensitive search
    #         query = Q()
    #         if title_check == "y":
    #             query.add(Q(title__icontains=strval), Q.OR)
    #             # query = Q(title__icontains=strval)
    #         if note_check == "y":
    #             query.add(Q(note__icontains=strval), Q.OR)
    #         if fund_code_check == "y":
    #             query.add(Q(fund_code__icontains=strval), Q.OR)
    #         if issuer_check != "all":
    #             query.add(Q(issuer__issuer__icontains=issuer_check), Q.AND)
    #         if fund_type_check != "all":
    #             query.add(Q(fund_type__fund_type__icontains=fund_type_check), Q.AND)
    #         if settlement_day_check != "all":
    #             query.add(Q(settlement_day__settlement_day__icontains=settlement_day_check), Q.AND)
    #         if currency_check != "all":
    #             query.add(Q(currency__currency__icontains=currency_check), Q.AND)
    #         if status_check != "all":
    #             query.add(Q(status__status__icontains=status_check), Q.AND)

    #         # fund_list = Fund.objects.filter(query).select_related().order_by('-updated_at')[:10] #old version order by time
    #         fund_list = Fund.objects.filter(query).select_related().order_by('fund_code')
    #     else :
    #         # fund_list = Fund.objects.all().order_by('-updated_at')[:10]
    #         fund_list = Fund.objects.all().order_by('fund_code')

    #     # Augment the fund_list
    #     for obj in fund_list:
    #         obj.natural_updated = naturaltime(obj.updated_at)
    #     #change end

    #     # fund_list = Fund.objects.all()
    #     favorites = list()
    #     if request.user.is_authenticated:
    #         # rows = [{'id': 2}, {'id': 4} ... ]  (A list of rows)
    #         rows = request.user.favorite_funds.values('id')
    #         # favorites = [2, 4, ...] using list comprehension
    #         favorites = [ row['id'] for row in rows ]

    #     sc = Status.objects.all().count()
    #     ic = Issuer.objects.all().count()
    #     ftc = Fund_type.objects.all().count()
    #     sdc = Settlement_day.objects.all().count()
    #     cc = Currency.objects.all().count()

    #     ia = Issuer.objects.all()
    #     fta = Fund_type.objects.all()
    #     sda = Settlement_day.objects.all()
    #     ca = Currency.objects.all()
    #     sa = Status.objects.all()

    #     ctx = {'fund_list' : fund_list, 'favorites': favorites, 'search': strval,
    #     'status_count': sc,
    #     'issuer_count': ic,
    #     'fund_type_count': ftc,
    #     'settlement_day_count': sdc,
    #     'currency_count': cc,
    #     'title_check' : title_check,
    #     'issuer_all':ia,
    #     'fund_type_all':fta,
    #     'settlement_day_all':sda,
    #     'currency_all':ca,
    #     'status_all':sa
    #     }

    #     return render(request, self.template_name, ctx)